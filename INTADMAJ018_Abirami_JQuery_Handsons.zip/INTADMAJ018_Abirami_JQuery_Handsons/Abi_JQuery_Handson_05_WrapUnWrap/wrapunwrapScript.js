$(document).ready(() => {
    var pTags = $("p");
    $("#wrapUnwrapPage").click(function () {
      if (pTags.parent().is("div")) {
        pTags.unwrap();
      } else {
        pTags.wrap("<div>");
      }
    });
  });