$(document).ready(
    function(){
        $('#btn').click(
            
            function(){
                var toAdd = $('input[id=text]').val();
                if(toAdd==="")
                {
                    alert("Enter task details!!");
                }
                else
                {
                 $('#paragraph1').append("<br>"+toAdd);
                 
                }
            });
        });
    